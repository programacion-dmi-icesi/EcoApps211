// Importar paquetes
// Configuracion de firebase
import {getFirebaseConfig} from './firebase-config.js';

// Modulos de firebase a utilizar
import { initializeApp } from 'firebase/app';
import {getDatabase, ref, get, onValue} from 'firebase/database';
import {getAuth, onAuthStateChanged} from 'firebase/auth';

// Inicializar y configurar firebase
const firebaseConf = getFirebaseConfig();
const app = initializeApp(firebaseConf);
const db = getDatabase();
const auth = getAuth();

// Elementos de la página
const email = document.getElementById("email");
const username = document.getElementById("username");
const edad = document.getElementById("edad");
const userid = document.getElementById("userid");
const logout_btn = document.getElementById("logout_btn");
const candidate_list = document.getElementById("candidate_list");


onAuthStateChanged(auth, (user_account)=>{
    if (user_account){
        // Hay usuario loguegado
        console.log("account", user_account);
        const dbRef = ref(db, "sem15/users/"+user_account.uid);
        get(dbRef)
        .then((snapshot) =>{
            console.log("snapshot", snapshot);
            const user = snapshot.val();
            console.log("user", user);
            username.innerHTML = "Bievenido "+user.username;
            userid.innerHTML = user.id;
            edad.innerHTML = user.edad;
            email.innerHTML = user.email;
        })
        .catch((error) => {
            console.log(error);
        });

        loadCandidatos();
    }else{
        window.location.href = "login.html";
    }
});

function logout(e, ev){
    auth.signOut()
    .then(()=> {
        window.location.href = "login.html"
    })
    .catch((error) => {
        console.log(error.message);
    });
}

logout_btn.addEventListener("click", logout);

function loadCandidatos(){
    const dbRef = ref(db, "candidatos");
    onValue(dbRef, (snapshot) => {
        console.log("candidate_snapshot", snapshot);
        const candidatos = snapshot.val();
        console.log("candidates", candidatos);
        candidate_list.innerHTML = "";
        Object.keys(candidatos).forEach((k, i) =>{
            candidate_list.innerHTML += candidatos[k].nombre + "</br>";
        });
    });
}
