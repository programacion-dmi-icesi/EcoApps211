/**
 * To find your Firebase config object:
 * 
 * 1. Go to your [Project settings in the Firebase console](https://console.firebase.google.com/project/_/settings/general/)
 * 2. In the "Your apps" card, select the nickname of the app for which you need a config object.
 * 3. Select Config from the Firebase SDK snippet pane.
 * 4. Copy the config object snippet, then add it here.
 */
const config = {
    apiKey: "AIzaSyA-zloOeP5HmY90iYhEgoC-Z7wR5Ndy-eg",
    authDomain: "eco-2021-2.firebaseapp.com",
    databaseURL: "https://eco-2021-2-default-rtdb.firebaseio.com",
    projectId: "eco-2021-2",
    storageBucket: "eco-2021-2.appspot.com",
    messagingSenderId: "186125145194",
    appId: "1:186125145194:web:e36b9e20af8984c5396613"
};

export function getFirebaseConfig() {
    if (!config || !config.apiKey) {
        throw new Error('No Firebase configuration object provided.' + '\n' +
            'Add your web app\'s configuration object to firebase-config.js');
    } else {
        return config;
    }
}
