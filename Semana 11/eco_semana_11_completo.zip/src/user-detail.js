import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, get, push, } from 'firebase/database';

import { getFirebaseConfig } from './firebase-config';

// Inicializar firebase
const firebaseAppConfig = getFirebaseConfig();
const firebaseApp = initializeApp(firebaseAppConfig);

const locals = window.localStorage;
const localUser = JSON.parse(locals.getItem("currentUser"));
const title = document.getElementById("user-nombre");
const identification = document.getElementById("user-identification");
const edad = document.getElementById("user-edad");
const password = document.getElementById("user-password");

const db = getDatabase();
const dbRef = ref(db, 'users/'+localUser.id);
get(dbRef).then((snapshot) =>{
    const data = snapshot.val();
    console.log("user", data);
    updatePage(data);
});

function updatePage(currentUser){
    title.innerHTML = currentUser.nombre;

    let normalText = document.createElement("span");
    normalText.className = "normal";
    normalText.innerHTML= currentUser.username + " ";

    let boldText = document.createElement("strong");
    boldText.innerHTML = currentUser.id;

    identification.appendChild(normalText);
    identification.appendChild(boldText);

    edad.innerHTML = currentUser.edad;
    password.innerHTML = currentUser.password;
}



