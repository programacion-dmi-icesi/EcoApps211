import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onValue, push } from 'firebase/database';

import { getFirebaseConfig } from './firebase-config';
import { userCard } from './user-card';

// Inicializar firebase
const firebaseAppConfig = getFirebaseConfig();
const firebaseApp = initializeApp(firebaseAppConfig);

function registrarUsuario(user){
    // Obtener la base datos
    const db = getDatabase();
    const newUserRef = push(ref(db, 'users'));
    console.log(newUserRef);

    // injectar el id
    user["id"] = newUserRef.key
    // escribir un nuevo usuario
    set(newUserRef, user);
}

function getUsuarios(){
    const db = getDatabase();
    const dbRef = ref(db, 'users');
    onValue(dbRef, (snapshot) =>{
        const data = snapshot.val();
        console.log("lista", data);
        actualizarLista(data);
    });
}

function actualizarLista(info){
    if (info) {
        userList.innerHTML="";
        Object.keys(info).forEach((k, index)=>{
            console.log(k, index);
            console.log("Objeto", info[k])
            const card = new userCard(info[k])
            userList.appendChild(card.render());
        });

    } else {
        userList.innerHTML = "No hay usuarios registrados";
    }
}

const username = document.getElementById("username");
const nombre = document.getElementById("nombre");
const edad = document.getElementById("edad");
const password = document.getElementById("password");
const registraBtn = document.getElementById("registrar_btn");
const userList = document.getElementById("userslist");
console.log(username);

const registroEvento = (e, event) => {
    console.log("ejecutó evento")
    const user = {
        username: username.value,
        nombre: nombre.value,
        edad: edad.value,
        pass: password.value
    }
    registrarUsuario(user)
}

registraBtn.addEventListener("click", registroEvento);
getUsuarios();
