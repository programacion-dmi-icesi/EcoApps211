import { getDatabase, ref, set, onValue, push } from 'firebase/database';

export class userCard{
    constructor(user){
        this.user = user;
    }

    render(){
        let card = document.createElement("div");
        card.className="user-card";

        let title = document.createElement("h3");
        title.className="user-card-title";
        title.innerHTML = this.user.nombre;
        title.addEventListener("click", (e, ev) => {
            const locals = window.localStorage;
            locals.setItem("currentUser", JSON.stringify(this.user));
            window.location.href = "user-detail.html";
        });

        let content = document.createElement("p");
        content.className = "user-card-content";
        content.innerHTML = this.user.username + " " +this.user.edad;

        let deleteBtn = document.createElement("button");
        deleteBtn.className = "user-card-delete";
        deleteBtn.innerHTML = "X";
        deleteBtn.addEventListener("click", (e, ev)=>{
            // Obtener la base datos
            const db = getDatabase();
            const userRef = ref(db, 'users/' + this.user.id);
            console.log(userRef);

            // escribir un nuevo usuario
            set(userRef, null);
        });

        card.appendChild(title);
        card.appendChild(content);
        card.appendChild(deleteBtn);
        return card;
    }
}
