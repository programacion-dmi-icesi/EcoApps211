const firebaseConfig = {
    apiKey: "AIzaSyA-zloOeP5HmY90iYhEgoC-Z7wR5Ndy-eg",
    authDomain: "eco-2021-2.firebaseapp.com",
    databaseURL: "https://eco-2021-2-default-rtdb.firebaseio.com",
    projectId: "eco-2021-2",
    storageBucket: "eco-2021-2.appspot.com",
    messagingSenderId: "186125145194",
    appId: "1:186125145194:web:3235771ee05b2864396613"
};

export function getFirebaseConfig(){
    if (!firebaseConfig || !firebaseConfig.apiKey){
        throw new Error("Firebase configuration error");
    } else {
        return firebaseConfig;
    }
}
