
//DECLARACIONES
const estudiante = document.getElementById('estudiante');
const codigo = document.getElementById('codigo');
const curso = document.getElementById('curso');
const matricularBtn = document.getElementById('matricularBtn');

matricular = () => {
    alert('Exito!');

}

matricularBtn.addEventListener('click', matricular);

//Me disculpo de antemano por entregar un código tan incompleto. Tuve un error intentando conectar JS con la base de datos, al momento de ingresar "npm run start" en la terminal no me funcionó. De ahi en adelante el código no me volvió a responder.



