package main;


import java.util.ArrayList;
import java.util.UUID;

import com.google.gson.Gson;

import processing.core.PApplet;

public class MainPeerB extends PApplet implements IObserver {
	
	
	private ComunicacionUDP com;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("main.MainPeerB");
	}
	
	public void settings() {
		size(500,500);
	}
	
	public void setup() {
		com = new ComunicacionUDP(this);
		com.start();
	}
	
	public void draw() {
		background(0,255,0);
	}
	
	public void mousePressed() {
		com.enviarMensajes("Enviado desde PeerB");
		
	}
	
	@Override
	public void onMessage(String message) {

	}
}



