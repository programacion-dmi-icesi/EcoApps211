package main;


public interface IObserver {
	public void onMessage(String message);

}
