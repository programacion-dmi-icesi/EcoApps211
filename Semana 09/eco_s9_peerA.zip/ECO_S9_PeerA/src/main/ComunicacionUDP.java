package main;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;


public class ComunicacionUDP extends Thread {

	private DatagramSocket ds;
	private IObserver app;

	public ComunicacionUDP(IObserver app) {
		this.app = app;

	}

	@Override
	public void run() {
		iniciarPeer();
	}

	public void iniciarPeer() {
		try {
			this.ds = new DatagramSocket(13001);
			
			recibirMensajes();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void recibirMensajes() {
		while(true) {
			byte[] buffer = new byte[1024];
			DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
			
			try {
				this.ds.receive(paquete); // esperando hasta que llegue un nuevo paquete
				
				String mensaje = new String(paquete.getData()).trim();
				System.out.println("Recibí mensaje: "+mensaje);
				
				app.onMessage(mensaje);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void enviarMensajes(String mensaje) {
		new Thread(()->{
			try {
				InetAddress peerIp = InetAddress.getByName("127.0.0.1");
				int peerPort = 13002;
				
				System.out.println("Enviando mensaje");
				
				DatagramPacket paquete = new DatagramPacket(
						mensaje.getBytes(), mensaje.getBytes().length, peerIp, peerPort);
				
				this.ds.send(paquete);
				
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}).start();
		
	}

	
}
