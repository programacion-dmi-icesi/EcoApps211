package main;


import com.google.gson.Gson;

import processing.core.PApplet;

public class MainPeerA extends PApplet implements IObserver {
	
	
	private ComunicacionUDP com;
	private Gson serializer;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("main.MainPeerA");
	}
	
	public void settings() {
		size(500,500);
	}
	
	public void setup() {
		com = new ComunicacionUDP(this);
		com.start();
		
	}
	
	public void draw() {
		background(255,0,0);

	}
	
	public void mousePressed() {
		com.enviarMensajes("Enviado desde PeerA");
	}
	
	@Override
	public void onMessage(String message) {

	}
}



